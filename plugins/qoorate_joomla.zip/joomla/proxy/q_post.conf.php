<?php
// These are the paths to the API server that teh proxy needs
define('QOORATE_BASE_URI', 'http://qrate.co');
define('QOORATE_UPLOADER_URI', 'http://qrate.co/q/uploader');
define('QOORATE_FEED_URI', 'http://qrate.co/q/feed');
define('QOORATE_EMBED_URI', 'http://qrate.co/q/embed');
define('QOORATE_JSON_URI', 'http://qrate.co/q/embed/json');
define('QOORATE_DEBUG', False);

