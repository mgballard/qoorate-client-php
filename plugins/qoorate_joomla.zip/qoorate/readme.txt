=== Plugin Name ===
Contributors: sethmurphy
Tags: comments
Requires at least: 3.4.0
Tested up to: 3.4.0
Stable tag: 3.4.0

Qoorate contribution plugin.

== Description ==
This plugin enables you to add the Qoorate Contribution Platform to your Wordpress installation replacing the built in commenting system.

== Installation ==

1. Upload the folder `qoorate` and all it's contents to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to settings -> qoorate and enter your API key, API secret and API short name.

== Frequently Asked Questions ==

= Where do I get my API information so I can use this contribution system? =

Go to http://qrate.co and request an account.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the directory of the stable readme.txt, so in this case, `/tags/4.3/screenshot-1.png` (or jpg, jpeg, gif)
2. This is the second screen shot

== Changelog ==

= 0.1 =
* Initial plug-in release.

