<?php
// These are the paths to the API server that the proxy needs
define('QOORATE_BASE_URI', 'http://qoorate.sethmurphy.com/q');
define('QOORATE_UPLOADER_URI', 'http://qoorate.sethmurphy.com/uploader');
define('QOORATE_FEED_URI', 'http://qoorate.sethmurphy.com/q/feed');
define('QOORATE_EMBED_URI', 'http://qoorate.sethmurphy.com/q/embed');
