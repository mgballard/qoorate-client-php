<?php
// These are the paths to the API server that the proxy needs
define('QOORATE_BASE_URI', 'http://qrate.co/q');
define('QOORATE_UPLOADER_URI', 'http://qrate.co/uploader');
define('QOORATE_FEED_URI', 'http://qrate.co/q/feed');
define('QOORATE_EMBED_URI', 'http://qrate.co/q/embed');
